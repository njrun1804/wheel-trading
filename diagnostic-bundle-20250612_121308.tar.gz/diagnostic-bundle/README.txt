Diagnostic Bundle Summary
========================
Created: Thu Jun 12 12:13:13 EDT 2025
Project: wheel-trading
Path: /Users/mikeedwards/Library/Mobile Documents/com~apple~CloudDocs/pMike/Wheel/wheel-trading
User: mikeedwards
OS: Darwin 24.5.0

Files collected:
      64

Total size:
308K	diagnostic-bundle
