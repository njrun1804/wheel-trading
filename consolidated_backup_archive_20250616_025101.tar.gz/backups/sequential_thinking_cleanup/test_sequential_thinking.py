#!/usr/bin/env python3
"""Test hardware-accelerated sequential thinking."""

import asyncio
import time
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from src.unity_wheel.accelerated_tools.sequential_thinking_turbo import get_sequential_thinking
from src.unity_wheel.accelerated_tools.sequential_thinking_config import SequentialThinkingEngine


async def test_direct_turbo():
    """Test direct hardware-accelerated implementation."""
    print("\n=== Testing Direct Turbo Implementation ===")
    
    thinking = get_sequential_thinking()
    
    # Test with a complex problem
    start_time = time.time()
    
    steps = await thinking.think(
        goal="Optimize a trading algorithm for maximum performance",
        constraints=[
            "Must use all available CPU cores",
            "Leverage GPU for calculations",
            "Maintain low latency",
            "Handle real-time data"
        ],
        strategy='parallel_explore',
        max_steps=20
    )
    
    elapsed = time.time() - start_time
    
    print(f"\nCompleted in {elapsed:.2f} seconds")
    print(f"Generated {len(steps)} thinking steps")
    print(f"\nPerformance stats: {thinking.get_stats()}")
    
    # Show some steps
    print("\nFirst 5 steps:")
    for step in steps[:5]:
        print(f"  Step {step.step_number}: {step.action} (confidence: {step.confidence:.2f})")
    
    return elapsed, len(steps)


async def test_config_wrapper():
    """Test the configuration wrapper."""
    print("\n=== Testing Configuration Wrapper ===")
    
    engine = SequentialThinkingEngine(use_mcp=False)
    
    start_time = time.time()
    
    result = await engine.think_through_problem(
        problem="Design a high-frequency trading system",
        constraints=[
            "Sub-millisecond latency required",
            "Must handle 1M orders/second",
            "Risk management essential"
        ],
        max_steps=15,
        strategy='beam_search'
    )
    
    elapsed = time.time() - start_time
    
    print(f"\nCompleted in {elapsed:.2f} seconds")
    print(f"Solution status: {result['solution']['status']}")
    print(f"Confidence: {result['solution']['confidence']:.2f}")
    print(f"Total steps: {result['solution']['total_steps']}")
    
    # Hardware utilization
    stats = result.get('stats', {})
    print(f"\nHardware utilization:")
    print(f"  CPU cores used: {stats.get('cpu_cores_used', 'N/A')}")
    print(f"  GPU available: {stats.get('gpu_available', False)}")
    print(f"  GPU-accelerated steps: {stats.get('gpu_accelerated_steps', 0)}")
    print(f"  Parallel branches: {stats.get('parallel_branches', 0)}")
    
    return elapsed, result['solution']['total_steps']


async def test_jarvis2_integration():
    """Test integration with jarvis2."""
    print("\n=== Testing Jarvis2 Integration ===")
    
    try:
        from jarvis2.core.jarvis2 import Jarvis2
        
        jarvis = Jarvis2()
        await jarvis.initialize()
        
        start_time = time.time()
        
        # Test with a complex query that should trigger sequential thinking
        solution = await jarvis.assist(
            query="Implement a GPU-accelerated options pricing model with Greeks calculation",
            context={"complexity_hint": "high"}
        )
        
        elapsed = time.time() - start_time
        
        print(f"\nJarvis2 completed in {elapsed:.2f} seconds")
        print(f"Solution confidence: {solution.confidence:.2f}")
        print(f"Complexity score: {solution.metrics.complexity_score:.2f}")
        
        # Check if sequential thinking was used
        if hasattr(jarvis, 'sequential_thinking'):
            print("\n✓ Sequential thinking is integrated in Jarvis2")
        else:
            print("\n✗ Sequential thinking NOT found in Jarvis2")
            
    except Exception as e:
        print(f"\nJarvis2 integration test failed: {e}")
        import traceback
        traceback.print_exc()


async def compare_performance():
    """Compare with MCP server performance."""
    print("\n=== Performance Comparison ===")
    
    # Our hardware-accelerated version
    turbo_time, turbo_steps = await test_direct_turbo()
    
    print(f"\nHardware-accelerated sequential thinking:")
    print(f"  Time: {turbo_time:.2f}s")
    print(f"  Steps: {turbo_steps}")
    print(f"  Steps/second: {turbo_steps/turbo_time:.1f}")
    
    # MCP server baseline (from previous benchmarks)
    mcp_baseline_time = 2.5  # seconds for 20 steps
    mcp_baseline_steps = 20
    
    print(f"\nMCP server baseline (estimated):")
    print(f"  Time: {mcp_baseline_time:.2f}s")
    print(f"  Steps: {mcp_baseline_steps}")
    print(f"  Steps/second: {mcp_baseline_steps/mcp_baseline_time:.1f}")
    
    speedup = mcp_baseline_time / (turbo_time * mcp_baseline_steps / turbo_steps)
    print(f"\nSpeedup: {speedup:.1f}x faster than MCP server")


async def main():
    """Run all tests."""
    print("Testing Hardware-Accelerated Sequential Thinking")
    print("=" * 50)
    
    # Test individual components
    await test_direct_turbo()
    await test_config_wrapper()
    
    # Test integration
    await test_jarvis2_integration()
    
    # Performance comparison
    await compare_performance()
    
    print("\n" + "=" * 50)
    print("All tests completed!")


if __name__ == "__main__":
    asyncio.run(main())