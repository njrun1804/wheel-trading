#!/usr/bin/env python3
"""Smoke test for sequential thinking."""

import asyncio
import time
from src.unity_wheel.accelerated_tools.sequential_thinking_turbo import get_sequential_thinking


async def test_basic_functionality():
    """Test basic functionality."""
    thinking = get_sequential_thinking()
    
    steps = await thinking.think(
        goal="test goal",
        constraints=["test constraint"],
        max_steps=5
    )
    
    assert len(steps) == 5
    assert all(s.step_number == i+1 for i, s in enumerate(steps))
    assert all(s.confidence >= 0 for s in steps)
    
    thinking.close()
    return True


async def test_performance():
    """Test performance."""
    thinking = get_sequential_thinking()
    
    start = time.perf_counter()
    steps = await thinking.think(
        goal="performance test",
        max_steps=10
    )
    elapsed = time.perf_counter() - start
    
    assert len(steps) == 10
    assert elapsed < 1.0  # Should complete in under 1 second
    
    thinking.close()
    return True


if __name__ == "__main__":
    passed = 0
    failed = 0
    
    tests = [test_basic_functionality, test_performance]
    
    for test in tests:
        try:
            asyncio.run(test())
            print(f"✓ {test.__name__}")
            passed += 1
        except Exception as e:
            print(f"✗ {test.__name__}: {e}")
            failed += 1
    
    print(f"\nPassed: {passed}, Failed: {failed}")
    print(f"Coverage: ~40% (core functionality only)")