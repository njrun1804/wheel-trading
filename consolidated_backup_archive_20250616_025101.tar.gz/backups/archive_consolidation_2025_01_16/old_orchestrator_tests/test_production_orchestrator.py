#!/usr/bin/env python3
"""Test the complete production Deep MCTS orchestrator."""

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.unity_wheel.orchestrator.production_orchestrator import create_production_orchestrator


async def test_production_features():
    """Test all production features."""
    print("=" * 70)
    print("Production Deep MCTS Orchestrator Test")
    print("=" * 70)
    
    # Create orchestrator
    print("\n1. Creating production orchestrator...")
    orchestrator = await create_production_orchestrator(".")
    print("✓ Orchestrator created with shadow learning and diversity pipeline")
    
    # Test cases covering all complexity levels
    test_cases = [
        {
            "id": "simple",
            "command": "Fix typo in variable name 'calcualte' to 'calculate'",
            "expected_complexity": "low",
            "expected_strategy": "fast"
        },
        {
            "id": "medium", 
            "command": "Add error handling to the options pricing module",
            "expected_complexity": "medium",
            "expected_strategy": "enhanced"
        },
        {
            "id": "complex",
            "command": "Refactor the entire risk analytics engine to support multi-asset portfolios with cross-correlations and real-time updates",
            "expected_complexity": "high",
            "expected_strategy": "enhanced/diversity"
        }
    ]
    
    print(f"\n2. Running {len(test_cases)} test cases...\n")
    
    for i, test_case in enumerate(test_cases):
        print(f"Test {i+1}: {test_case['id']} complexity")
        print(f"Command: {test_case['command'][:60]}...")
        
        # Execute
        result = await orchestrator.execute(test_case['command'])
        
        # Display results
        print(f"Strategy: {result.get('strategy', 'unknown')}")
        
        if "execution_metrics" in result:
            metrics = result["execution_metrics"]
            print(f"Latency: {metrics.get('duration_ms', 0):.1f}ms")
            print(f"Energy: {metrics.get('energy_mj', 0):.1f}mJ")
            print(f"Memory: {metrics.get('memory_mb', 0):.1f}MB")
        
        if "phases" in result:
            phases = result["phases"]
            if "generation" in phases:
                gen = phases["generation"]
                print(f"Solutions generated: {gen.get('solutions_generated', 0)}")
                print(f"Variants used: {gen.get('variants_used', 0)}")
            elif "assess" in phases:
                assess = phases["assess"]
                print(f"Files found: {len(assess.get('relevant_files', []))}")
                print(f"Confidence: {assess.get('confidence', 0):.2f}")
        
        print(f"Success: {'✓' if result.get('performance', {}).get('success', False) else '✗'}")
        print("-" * 50)
    
    # Test shadow learning
    print("\n3. Testing shadow learning...")
    if orchestrator.shadow_learning:
        stats = orchestrator.shadow_learning.get_statistics()
        print(f"Experiences collected: {stats['experience_buffer']['total_experiences']}")
        print(f"Buffer memory: {stats['experience_buffer']['buffer_memory_mb']:.1f}MB")
        print(f"Success rate: {stats['experience_buffer']['success_rate']:.1%}")
        print("✓ Shadow learning active")
    
    # Test model update readiness
    print("\n4. Testing model update system...")
    can_update = orchestrator.shadow_learning.replay_manager.should_update()
    print(f"Ready for update: {'Yes' if can_update else 'No (need more data)'}")
    
    # Test diversity pipeline
    print("\n5. Testing diversity pipeline...")
    if orchestrator.policy_loader:
        loaded_models = list(orchestrator.policy_loader.loaded_models.keys())
        print(f"Loaded model variants: {loaded_models}")
        print("✓ Diversity pipeline available")
    
    # Test GPU acceleration
    print("\n6. Testing GPU acceleration...")
    if orchestrator.gpu_accelerator.available:
        gpu_stats = orchestrator.gpu_accelerator.get_memory_stats()
        print(f"GPU backend: {gpu_stats['backend']}")
        print(f"Available memory: {gpu_stats['available_mb']:.1f}MB")
        print("✓ GPU acceleration active")
    else:
        print("✗ No GPU available")
    
    # Get production metrics
    print("\n7. Production metrics summary:")
    metrics = orchestrator.get_production_metrics()
    
    print(f"Total executions: {metrics['total_executions']}")
    print(f"Strategy distribution:")
    for strategy, count in metrics['strategy_distribution'].items():
        print(f"  - {strategy}: {count}")
    
    print(f"Average latency by complexity:")
    for bucket, stats in metrics['avg_latency_by_complexity'].items():
        print(f"  - {bucket}: {stats['avg_ms']:.1f}ms (n={stats['count']})")
    
    # Test complexity estimator adaptation
    print("\n8. Testing adaptive complexity estimation...")
    estimator = orchestrator._strategies[orchestrator._default_strategy].complexity_estimator
    print(f"Adaptive thresholds: {[f'{t:.3f}' for t in estimator.thresholds]}")
    print(f"History size: {len(estimator.history)}")
    
    # Shutdown
    print("\n9. Shutting down...")
    await orchestrator.shutdown()
    print("✓ Clean shutdown complete")
    
    print("\n" + "=" * 70)
    print("All production features tested successfully!")
    print("=" * 70)


async def test_edge_cases():
    """Test edge cases and error handling."""
    print("\n" + "=" * 70)
    print("Edge Case Testing")
    print("=" * 70)
    
    orchestrator = await create_production_orchestrator(".")
    
    edge_cases = [
        {
            "name": "Empty command",
            "command": ""
        },
        {
            "name": "Very long command",
            "command": "Refactor " * 100 + "everything"
        },
        {
            "name": "Special characters",
            "command": "Fix bug in @#$%^&* module"
        },
        {
            "name": "Memory pressure simulation",
            "command": "Optimize memory usage",
            "simulate_pressure": True
        }
    ]
    
    for test in edge_cases:
        print(f"\nTesting: {test['name']}")
        
        try:
            # Simulate memory pressure if requested
            if test.get("simulate_pressure"):
                # Artificially increase memory pressure
                orchestrator.memory_monitor.pressure_high = True
            
            result = await orchestrator.execute(test["command"])
            print(f"Result: {result.get('strategy', 'unknown')} strategy")
            print(f"Success: {'✓' if result.get('performance', {}).get('success', False) else '✗'}")
            
        except Exception as e:
            print(f"✗ Error handled: {type(e).__name__}: {str(e)[:50]}")
        
        finally:
            # Reset any simulations
            orchestrator.memory_monitor.pressure_high = False
    
    await orchestrator.shutdown()
    print("\nEdge case testing complete")


async def benchmark_performance():
    """Benchmark performance across different scenarios."""
    print("\n" + "=" * 70)
    print("Performance Benchmarking")
    print("=" * 70)
    
    orchestrator = await create_production_orchestrator(".")
    
    scenarios = [
        ("Simple tasks", ["Fix typo", "Add comment", "Rename variable"], 10),
        ("Medium tasks", ["Add error handling", "Implement feature", "Write tests"], 5),
        ("Complex tasks", ["Refactor architecture", "Optimize performance"], 2)
    ]
    
    for scenario_name, commands, iterations in scenarios:
        print(f"\n{scenario_name} ({iterations} iterations each):")
        
        latencies = []
        for command in commands:
            for _ in range(iterations):
                result = await orchestrator.execute(command)
                if "execution_metrics" in result:
                    latencies.append(result["execution_metrics"]["duration_ms"])
        
        if latencies:
            import numpy as np
            print(f"  Average: {np.mean(latencies):.1f}ms")
            print(f"  P95: {np.percentile(latencies, 95):.1f}ms")
            print(f"  Min/Max: {min(latencies):.1f}/{max(latencies):.1f}ms")
    
    await orchestrator.shutdown()
    print("\nBenchmarking complete")


if __name__ == "__main__":
    import numpy as np  # For stats
    
    async def main():
        # Run all tests
        await test_production_features()
        await test_edge_cases()
        await benchmark_performance()
        
        print("\n✓ All tests completed successfully!")
    
    # Run async tests
    asyncio.run(main())