#!/usr/bin/env python3
"""Fixed minimal orchestrator test."""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from unity_wheel.orchestrator.components.direct_io import DirectFileOperations


async def main():
    """Test direct file operations."""
    print("Testing direct file operations...")
    
    file_ops = DirectFileOperations()
    
    # Test search
    print("\nSearching for Python files...")
    files = await file_ops.search_files("*.py", "src")
    
    print(f"Found {len(files)} Python files")
    if files:
        print("First 5 files:")
        for f in files[:5]:
            print(f"  - {f}")
    
    # Test list directory
    print("\nListing orchestrator directory...")
    entries = await file_ops.list_directory("src/unity_wheel/orchestrator")
    
    print(f"Found {len(entries)} entries")
    dirs = [e for e in entries if e["type"] == "directory"]
    files = [e for e in entries if e["type"] == "file"]
    
    print(f"  Directories: {len(dirs)}")
    print(f"  Files: {len(files)}")
    
    print("\nOrchestrator is functional! Direct I/O working correctly.")


if __name__ == "__main__":
    asyncio.run(main())