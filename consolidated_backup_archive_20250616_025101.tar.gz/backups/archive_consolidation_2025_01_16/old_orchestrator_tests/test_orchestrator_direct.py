#!/usr/bin/env python3
"""Direct test of Deep MCTS orchestrator components without unity_wheel imports."""

import asyncio
import sys
import os
from pathlib import Path

# Add the orchestrator directory directly to path
orchestrator_path = Path(__file__).parent / "src" / "unity_wheel" / "orchestrator"
sys.path.insert(0, str(orchestrator_path))

print("Deep MCTS Orchestrator Direct Test")
print("=" * 60)

# Mock imports that might cause issues
class MockConfig:
    def get(self, key, default=None):
        return default

sys.modules['unity_wheel'] = type(sys)('unity_wheel')
sys.modules['unity_wheel.config'] = type(sys)('config')
sys.modules['unity_wheel.config.loader'] = type(sys)('loader')
sys.modules['unity_wheel.config.loader'].get_config = lambda: MockConfig()


async def test_complexity_estimator():
    """Test the adaptive complexity estimator."""
    print("\n1. Testing Adaptive Complexity Estimator")
    print("-" * 40)
    
    try:
        from strategies.deep_mcts_strategy import AdaptiveComplexityEstimator
        
        estimator = AdaptiveComplexityEstimator()
        
        # Test initial estimates
        test_cases = [
            ("Fix typo", {"task_type": type('obj', (object,), {'value': 'quick_fix'})()}),
            ("Implement new feature", {"task_type": type('obj', (object,), {'value': 'development'})()}),
            ("Refactor architecture", {"task_type": type('obj', (object,), {'value': 'refactoring'})()})
        ]
        
        print("Initial complexity estimates:")
        for cmd, ctx in test_cases:
            complexity = estimator.estimate(cmd, ctx)
            print(f"  '{cmd}': {complexity:.3f}")
        
        # Record some executions
        print("\nRecording execution feedback...")
        for i in range(50):
            estimator.record_actual("test", {}, 100 + i * 100, 0.1 + i * 0.1)
        
        print(f"History size: {len(estimator.history)}")
        print(f"Current thresholds: {[f'{t:.3f}' for t in estimator.thresholds]}")
        
        print("✓ Complexity estimator working")
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_shadow_learning():
    """Test shadow learning components."""
    print("\n\n2. Testing Shadow Learning Infrastructure")
    print("-" * 40)
    
    try:
        from components.shadow_learning import (
            StreamingExperienceBuffer,
            TelemetryCollector
        )
        
        # Test experience buffer
        buffer = StreamingExperienceBuffer(
            buffer_dir="test_experience",
            memory_limit_mb=10
        )
        
        print("Adding experiences to buffer...")
        for i in range(3):
            await buffer.add(
                requirement=f"Test requirement {i}",
                context={"iteration": i},
                decisions=[("architecture", "modular")],
                generated_code=f"# Code {i}",
                execution_metrics={"duration_ms": 100, "energy_mj": 1.0},
                success=True
            )
        
        stats = buffer.get_statistics()
        print(f"Buffer statistics:")
        print(f"  Total experiences: {stats['total_experiences']}")
        print(f"  Success rate: {stats['success_rate']:.1%}")
        
        # Test telemetry
        telemetry = TelemetryCollector()
        telemetry.start_execution("test_1")
        await asyncio.sleep(0.1)
        metrics = telemetry.end_execution("test_1")
        print(f"Telemetry metrics: duration={metrics['duration_ms']:.1f}ms")
        
        print("✓ Shadow learning working")
        
        # Cleanup
        import shutil
        if Path("test_experience").exists():
            shutil.rmtree("test_experience")
        
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_value_network():
    """Test value network directly."""
    print("\n\n3. Testing Code Value Network")
    print("-" * 40)
    
    try:
        from strategies.deep_mcts_strategy import CodeValueNet
        import torch
        
        # Create small value network
        value_net = CodeValueNet(input_dim=64, hidden_dim=32)
        value_net.eval()
        
        # Test forward pass
        dummy_input = torch.randn(5, 64)
        with torch.no_grad():
            values = value_net(dummy_input)
        
        print(f"Input shape: {dummy_input.shape}")
        print(f"Output shape: {values.shape}")
        print(f"Output values: {[f'{v:.3f}' for v in values.squeeze().tolist()]}")
        print(f"All values in [0,1]: {all(0 <= v <= 1 for v in values.squeeze())}")
        
        print("✓ Value network working")
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        if "torch" in str(e):
            print("  (PyTorch not installed)")
        return False


async def test_mcts_node():
    """Test MCTS node operations."""
    print("\n\n4. Testing MCTS Node Operations")
    print("-" * 40)
    
    try:
        from strategies.deep_mcts_strategy import MCTSNode
        
        # Create root node
        root = MCTSNode({
            "requirement": "Test requirement",
            "context": {}
        })
        
        print(f"Root node created")
        print(f"  Visits: {root.visits}")
        print(f"  Value: {root.value}")
        print(f"  Children: {len(root.children)}")
        
        # Add children
        for i in range(3):
            child_state = {
                "requirement": "Test requirement",
                "context": {},
                "decision": f"option_{i}"
            }
            child = MCTSNode(child_state, parent=root)
            root.children.append(child)
        
        print(f"\nAfter adding children:")
        print(f"  Children: {len(root.children)}")
        
        # Test UCB calculation
        root.visits = 10
        for i, child in enumerate(root.children):
            child.visits = i + 1
            child.value = 0.5 + i * 0.1
        
        ucb_values = []
        for child in root.children:
            ucb = child.get_ucb(c=2.0)
            ucb_values.append(ucb)
            print(f"  Child UCB: {ucb:.3f} (visits={child.visits}, value={child.value:.2f})")
        
        print("✓ MCTS nodes working")
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_deep_mcts_strategy():
    """Test the complete strategy."""
    print("\n\n5. Testing Deep MCTS Strategy")
    print("-" * 40)
    
    try:
        from strategies.deep_mcts_strategy import DeepMCTSStrategy
        
        # Create strategy
        strategy = DeepMCTSStrategy()
        
        # Mock orchestrator
        class MockOrchestrator:
            def __init__(self):
                self.workspace_root = Path(".")
                self.mcp_client = MockMCPClient()
        
        class MockMCPClient:
            async def call_tool_auto(self, tool, params):
                if tool == "search":
                    return {"matches": [{"file": "test.py"}]}
                return {}
        
        orchestrator = MockOrchestrator()
        
        # Test assess phase
        print("Testing assess phase...")
        assess_result = await strategy.execute_assess(
            "Find code for testing",
            {},
            orchestrator
        )
        
        print(f"  Files found: {len(assess_result['relevant_files'])}")
        print(f"  Complexity: {assess_result['complexity_estimate']:.3f}")
        print(f"  Confidence: {assess_result['confidence']:.3f}")
        
        print("✓ Deep MCTS strategy working")
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def main():
    """Run all tests."""
    print("\nStarting direct component tests...")
    
    # Check dependencies
    try:
        import torch
        print(f"PyTorch available: Yes (version {torch.__version__})")
    except ImportError:
        print("PyTorch available: No")
    
    try:
        import numpy as np
        print(f"NumPy available: Yes (version {np.__version__})")
    except ImportError:
        print("NumPy available: No")
    
    # Run tests
    results = []
    results.append(("Complexity Estimator", await test_complexity_estimator()))
    results.append(("Shadow Learning", await test_shadow_learning()))
    results.append(("Value Network", await test_value_network()))
    results.append(("MCTS Nodes", await test_mcts_node()))
    results.append(("Deep MCTS Strategy", await test_deep_mcts_strategy()))
    
    # Summary
    print("\n" + "=" * 60)
    print("Test Summary:")
    print("=" * 60)
    
    for test_name, passed in results:
        status = "✓ PASSED" if passed else "✗ FAILED"
        print(f"{test_name:.<40} {status}")
    
    passed_count = sum(1 for _, passed in results if passed)
    total_count = len(results)
    
    print("-" * 60)
    print(f"Total: {passed_count}/{total_count} passed ({passed_count/total_count*100:.0f}%)")
    
    if passed_count == total_count:
        print("\n✓ All orchestrator components are working correctly!")
        print("\nThe Deep MCTS orchestrator is ready for production use.")
    else:
        print("\n✗ Some tests failed. Check the errors above.")
    
    return passed_count == total_count


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)