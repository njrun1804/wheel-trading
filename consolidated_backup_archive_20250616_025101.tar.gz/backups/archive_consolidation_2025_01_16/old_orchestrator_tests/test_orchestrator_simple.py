#!/usr/bin/env python3
"""Simple test of orchestrator functionality."""

import os
import sys
import asyncio
from pathlib import Path

# Force direct I/O mode to bypass MCP issues
os.environ["USE_MCP_SERVERS"] = "0"
os.environ["USE_GPU_ACCELERATION"] = "true"
os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))


async def test_orchestrator():
    """Test basic orchestrator functionality."""
    print("🧪 Testing Orchestrator with Hardware Acceleration\n")
    
    # Test 1: Basic functionality
    print("Test 1: Basic file operations")
    print("-" * 50)
    
    from unity_wheel.orchestrator.components.direct_io import DirectFileOperations
    file_ops = DirectFileOperations()
    
    # Search for Python files
    files = await file_ops.glob_files("*.py", "src/unity_wheel/strategy")
    print(f"Found {len(files)} Python files in strategy directory")
    
    # Test 2: Parallel execution
    print("\nTest 2: Parallel CPU execution")
    print("-" * 50)
    
    from unity_wheel.orchestrator.components.parallel_executor import ParallelExecutor
    
    def cpu_intensive_task(n):
        """Simulate CPU-intensive work."""
        total = 0
        for i in range(n * 1000000):
            total += i
        return total
    
    parallel_exec = ParallelExecutor()
    parallel_exec.start()
    
    # Run tasks in parallel
    import time
    start = time.time()
    items = list(range(12))  # 12 tasks for 12 cores
    results = await parallel_exec.map_cpu_bound(cpu_intensive_task, items)
    elapsed = time.time() - start
    
    print(f"Processed {len(items)} CPU tasks in {elapsed:.2f}s")
    print(f"Results: {len(results)} completed")
    
    parallel_exec.shutdown()
    
    # Test 3: GPU detection
    print("\nTest 3: GPU availability")
    print("-" * 50)
    
    try:
        import torch
        if torch.backends.mps.is_available():
            print("✅ Metal Performance Shaders available")
            device = torch.device("mps")
            
            # Simple GPU test
            x = torch.randn(1000, 1000, device=device)
            y = torch.matmul(x, x)
            torch.mps.synchronize()
            print(f"GPU matrix multiplication successful: shape {y.shape}")
        else:
            print("❌ MPS not available")
    except ImportError:
        print("❌ PyTorch not installed")
    
    # Test 4: Full orchestrator (simplified mode)
    print("\nTest 4: Orchestrator execution")
    print("-" * 50)
    
    try:
        from unity_wheel.orchestrator.orchestrator_consolidated import ConsolidatedOrchestrator
        
        orchestrator = ConsolidatedOrchestrator(".")
        await orchestrator.initialize()
        
        # Execute a simple command
        result = await orchestrator.execute("list all trading strategy files")
        
        print(f"Strategy used: {result.get('strategy', 'unknown')}")
        print(f"Success: {result.get('performance', {}).get('success', False)}")
        
        await orchestrator.shutdown()
        
    except Exception as e:
        print(f"❌ Orchestrator error: {e}")
    
    print("\n✅ Testing complete!")


if __name__ == "__main__":
    asyncio.run(test_orchestrator())