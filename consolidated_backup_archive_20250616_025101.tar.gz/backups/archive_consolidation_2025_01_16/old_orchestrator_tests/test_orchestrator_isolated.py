#!/usr/bin/env python3
"""Isolated test for Deep MCTS orchestrator components."""

import asyncio
import sys
import os
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

# Test individual components first
print("Testing Deep MCTS Orchestrator Components")
print("=" * 60)

async def test_complexity_estimator():
    """Test the adaptive complexity estimator."""
    print("\n1. Testing Adaptive Complexity Estimator")
    print("-" * 40)
    
    try:
        from unity_wheel.orchestrator.strategies.deep_mcts_strategy import AdaptiveComplexityEstimator
        
        estimator = AdaptiveComplexityEstimator()
        
        # Test initial estimates
        test_cases = [
            ("Fix typo", {"task_type": type('obj', (object,), {'value': 'quick_fix'})()}),
            ("Implement new feature with comprehensive testing", {"task_type": type('obj', (object,), {'value': 'development'})()}),
            ("Refactor entire architecture for microservices", {"task_type": type('obj', (object,), {'value': 'refactoring'})()})
        ]
        
        print("Initial complexity estimates:")
        for cmd, ctx in test_cases:
            complexity = estimator.estimate(cmd, ctx)
            print(f"  '{cmd[:40]}...': {complexity:.3f}")
        
        print("\nSimulating execution feedback...")
        # Record some actual executions
        for _ in range(50):
            estimator.record_actual("Fix typo", {"task_type": type('obj', (object,), {'value': 'quick_fix'})()}, 100, 0.1)
            estimator.record_actual("Implement feature", {"task_type": type('obj', (object,), {'value': 'development'})()}, 5000, 1.0)
            estimator.record_actual("Refactor", {"task_type": type('obj', (object,), {'value': 'refactoring'})()}, 30000, 3.0)
        
        print(f"Recorded {len(estimator.history)} samples")
        print(f"Current thresholds: {[f'{t:.3f}' for t in estimator.thresholds]}")
        
        print("✓ Complexity estimator working")
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_shadow_learning():
    """Test shadow learning components."""
    print("\n\n2. Testing Shadow Learning Infrastructure")
    print("-" * 40)
    
    try:
        from unity_wheel.orchestrator.components.shadow_learning import (
            StreamingExperienceBuffer,
            TelemetryCollector,
            ExperienceReplayManager
        )
        
        # Test experience buffer
        buffer = StreamingExperienceBuffer(memory_limit_mb=10)  # Small limit for testing
        
        print("Adding experiences to buffer...")
        for i in range(5):
            await buffer.add(
                requirement=f"Test requirement {i}",
                context={"iteration": i},
                decisions=[("architecture", "modular"), ("testing", "unit")],
                generated_code=f"# Generated code {i}\nprint('test')",
                execution_metrics={"duration_ms": 100 + i * 10, "energy_mj": 1.0},
                success=True
            )
        
        stats = buffer.get_statistics()
        print(f"Buffer stats: {stats}")
        
        # Test telemetry
        telemetry = TelemetryCollector()
        telemetry.start_execution("test_exec_1")
        await asyncio.sleep(0.1)
        metrics = telemetry.end_execution("test_exec_1")
        print(f"Telemetry metrics: {metrics}")
        
        # Test replay manager
        replay = ExperienceReplayManager(buffer, min_experiences=5)
        print(f"Should update: {replay.should_update()}")
        
        print("✓ Shadow learning components working")
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_diversity_pipeline():
    """Test diversity pipeline components."""
    print("\n\n3. Testing Diversity Pipeline")
    print("-" * 40)
    
    try:
        from unity_wheel.orchestrator.components.diversity_pipeline import (
            PolicyNet,
            LazyPolicyLoader,
            SafeModelUpdater,
            BehavioralClusterer
        )
        import torch
        
        # Test PolicyNet
        print("Creating PolicyNet...")
        policy = PolicyNet(vocab_size=100, hidden_dim=64, num_layers=2)  # Small for testing
        
        # Test forward pass
        dummy_input = torch.randint(0, 100, (1, 10))
        with torch.no_grad():
            output = policy(dummy_input, "architecture")
        
        print(f"Policy output shape: {output.shape}")
        print(f"Output is valid probabilities: {torch.allclose(output.sum(), torch.tensor(1.0))}")
        
        # Test lazy loader (without actual model files)
        print("\nTesting LazyPolicyLoader...")
        loader = LazyPolicyLoader(max_loaded=2)
        print(f"Model configs: {list(loader.model_configs.keys())}")
        
        # Test clusterer
        print("\nTesting BehavioralClusterer...")
        clusterer = BehavioralClusterer()
        
        # Mock solutions
        solutions = [
            {"code": "def f(): return 1", "variant": "base"},
            {"code": "def f(): return 1", "variant": "creative"},  # Same behavior
            {"code": "def f(): return 2", "variant": "base"},
        ]
        
        clusters = await clusterer.cluster_solutions(
            solutions,
            test_cases=[{"input": "test"}],
            max_clusters=2
        )
        
        print(f"Found {len(clusters)} clusters")
        for i, cluster in enumerate(clusters):
            print(f"  Cluster {i}: {len(cluster)} solutions")
        
        print("✓ Diversity pipeline components working")
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_deep_mcts():
    """Test Deep MCTS core functionality."""
    print("\n\n4. Testing Deep MCTS")
    print("-" * 40)
    
    try:
        from unity_wheel.orchestrator.strategies.deep_mcts_strategy import (
            DeepMCTS,
            CodeValueNet
        )
        import torch
        
        # Create value network
        print("Creating value network...")
        value_net = CodeValueNet(input_dim=64, hidden_dim=32)  # Small for testing
        
        # Test value network
        dummy_features = torch.randn(1, 64)
        with torch.no_grad():
            value = value_net(dummy_features)
        
        print(f"Value network output: {value.item():.3f}")
        
        # Create MCTS
        print("\nCreating Deep MCTS...")
        mcts = DeepMCTS(value_net, c=2.0, gpu_batch_size=16)
        
        # Run search
        print("Running MCTS search...")
        result = await mcts.search(
            "Test requirement",
            {"test": True},
            simulations=100,
            time_budget_ms=5000
        )
        
        print(f"MCTS completed {result['simulations']} simulations")
        print(f"Search took {result['duration_ms']:.1f}ms")
        print(f"Confidence: {result['confidence']:.3f}")
        print(f"Path length: {len(result['path'])}")
        
        print("✓ Deep MCTS working")
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_integrated_strategy():
    """Test the complete Deep MCTS strategy."""
    print("\n\n5. Testing Integrated Deep MCTS Strategy")
    print("-" * 40)
    
    try:
        from unity_wheel.orchestrator.strategies.deep_mcts_strategy import DeepMCTSStrategy
        
        # Create mock orchestrator
        class MockOrchestrator:
            def __init__(self):
                self.workspace_root = Path(".")
                self.mcp_client = MockMCPClient()
        
        class MockMCPClient:
            async def call_tool_auto(self, tool, params):
                # Mock responses
                if tool == "search":
                    return {"matches": [{"file": "test.py"}, {"file": "main.py"}]}
                return {}
        
        # Create strategy
        strategy = DeepMCTSStrategy()
        orchestrator = MockOrchestrator()
        
        # Test assess phase
        print("Testing assess phase...")
        assess_result = await strategy.execute_assess(
            "Find code for testing", 
            {},
            orchestrator
        )
        
        print(f"Found {len(assess_result['relevant_files'])} files")
        print(f"Complexity estimate: {assess_result['complexity_estimate']:.3f}")
        print(f"Confidence: {assess_result['confidence']:.3f}")
        
        # Test plan phase
        print("\nTesting plan phase...")
        plan_result = await strategy.execute_plan(
            "Generate plan for testing",
            {"assess_result": assess_result},
            orchestrator
        )
        
        print(f"Explored {plan_result['alternatives_explored']} alternatives")
        print(f"Plan confidence: {plan_result['confidence']:.3f}")
        
        print("✓ Integrated strategy working")
        return True
        
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def main():
    """Run all component tests."""
    print("\nStarting component tests...")
    
    # Run tests
    results = []
    results.append(await test_complexity_estimator())
    results.append(await test_shadow_learning())
    results.append(await test_diversity_pipeline())
    results.append(await test_deep_mcts())
    results.append(await test_integrated_strategy())
    
    # Summary
    print("\n" + "=" * 60)
    print("Test Summary:")
    print(f"  Passed: {sum(results)}/{len(results)}")
    print(f"  Status: {'✓ All tests passed!' if all(results) else '✗ Some tests failed'}")
    print("=" * 60)
    
    return all(results)


if __name__ == "__main__":
    # Check for required packages
    try:
        import torch
        import numpy as np
    except ImportError:
        print("Missing required packages. Installing...")
        os.system("pip install torch numpy scikit-learn")
    
    # Run tests
    success = asyncio.run(main())
    sys.exit(0 if success else 1)