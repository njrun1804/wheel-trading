#!/usr/bin/env python3
"""Test script to verify enhanced orchestrator with M4 Pro optimizations."""

import asyncio
import sys
import time
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from unity_wheel.orchestrator.enhanced_session import create_enhanced_session


async def test_enhanced_orchestrator():
    """Test the enhanced orchestrator features."""
    print("🧪 Testing Enhanced Orchestrator with M4 Pro Optimizations")
    print("=" * 60)
    
    # Create session
    print("\n1️⃣ Creating enhanced session...")
    session = await create_enhanced_session(".")
    
    # Test 1: Simple command
    print("\n2️⃣ Testing simple command execution...")
    result = await session.execute("find all Python files in src/unity_wheel/analytics")
    print(f"   ✅ Found {len(result.get('phases', {}).get('implement', {}).get('results', []))} files")
    print(f"   ⚡ Duration: {result.get('session_metrics', {}).get('duration_ms', 0):.1f}ms")
    
    # Test 2: Complex analysis
    print("\n3️⃣ Testing complex code analysis...")
    result = await session.execute("analyze performance bottlenecks in the trading analytics functions")
    print(f"   ✅ Strategy: {result.get('strategy', 'unknown')}")
    print(f"   ⚡ Duration: {result.get('session_metrics', {}).get('duration_ms', 0):.1f}ms")
    print(f"   💾 Memory: +{result.get('session_metrics', {}).get('memory_delta_mb', 0):.1f}MB")
    
    # Test 3: GPU acceleration test
    print("\n4️⃣ Testing GPU acceleration...")
    result = await session.execute("optimize matrix operations in options pricing")
    backend = result.get('session_metrics', {}).get('backend', 'CPU')
    print(f"   ✅ Backend: {backend}")
    if backend == 'Metal':
        print("   🎯 M4 Pro GPU acceleration active!")
    
    # Test 4: Parallel execution
    print("\n5️⃣ Testing parallel execution...")
    commands = [
        "count Python files in src",
        "find all test files",
        "list configuration files"
    ]
    
    start = time.time()
    tasks = [session.execute(cmd) for cmd in commands]
    results = await asyncio.gather(*tasks)
    duration = (time.time() - start) * 1000
    
    print(f"   ✅ Executed {len(results)} commands in parallel")
    print(f"   ⚡ Total duration: {duration:.1f}ms")
    print(f"   🚀 Average per command: {duration/len(results):.1f}ms")
    
    # Display optimization summary
    print("\n📊 Optimization Summary:")
    settings = session.performance_settings
    if settings.get('optimizations_applied'):
        print(f"   • CPU Cores: {settings.get('cpu_cores', {}).get('total', 'Unknown')}")
        if 'performance' in settings.get('cpu_cores', {}):
            print(f"   • Performance Cores: {settings['cpu_cores']['performance']}")
            print(f"   • Efficiency Cores: {settings['cpu_cores']['efficiency']}")
        print(f"   • Memory: {settings.get('memory_gb', 0):.1f} GB")
        print(f"   • Backend: {settings.get('backend', 'CPU')}")
        if settings.get('gpu_cores'):
            print(f"   • GPU Cores: {settings['gpu_cores']}")
        if settings.get('ramdisk'):
            print(f"   • RAM Disk: {settings['ramdisk']}")
    
    # Cleanup
    await session.shutdown()
    
    print("\n✅ All tests completed successfully!")
    print("🚀 The orchestrator is now optimized for your hardware!\n")


if __name__ == "__main__":
    asyncio.run(test_enhanced_orchestrator())