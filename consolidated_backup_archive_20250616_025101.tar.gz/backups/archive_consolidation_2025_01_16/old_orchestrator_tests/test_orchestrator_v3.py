#!/usr/bin/env python3
"""Test the GPU-accelerated orchestrator in isolation."""

import asyncio
import sys
import os
from pathlib import Path

# Add src to path directly
sys.path.insert(0, str(Path(__file__).parent / "src"))

# Enable MLX mixed precision
os.environ["MLX_MIXED_PRECISION"] = "1"

async def test_orchestrator():
    """Test the GPU-accelerated orchestrator components."""
    print("🚀 Testing GPU-Accelerated Orchestrator Components")
    
    # Test 1: MCTS Code Explorer
    print("\n1. Testing MCTS Code Explorer...")
    try:
        from unity_wheel.orchestrator.mcts_code_explorer import MCTSCodeExplorer
        
        mcts = MCTSCodeExplorer(batch_size=32, use_gpu=True)
        
        # Simple test state
        test_state = {
            "command": "optimize Greek calculations",
            "files": ["options.py", "risk.py"],
            "constraints": {"maintain_accuracy": True}
        }
        
        result = await mcts.search(
            test_state, 
            time_budget_ms=5000,  # 5 seconds
            early_stop_threshold=0.8
        )
        
        print(f"  ✅ MCTS explored {result['nodes_explored']} nodes")
        print(f"  ✅ Best value: {result['best_value']:.2f}")
        print(f"  ✅ GPU utilization: {result['gpu_utilization']:.1%}")
    except Exception as e:
        print(f"  ❌ MCTS test failed: {e}")
    
    # Test 2: Population-Based Training
    print("\n2. Testing Population-Based Training...")
    try:
        from unity_wheel.orchestrator.population_based_strategies import PopulationBasedTrainer
        
        pbt = PopulationBasedTrainer(population_size=10)
        print(f"  ✅ PBT initialized with {len(pbt.population)} strategies")
        print(f"  ✅ Strategy types: {set(s.strategy_type.value for s in pbt.population)}")
    except Exception as e:
        print(f"  ❌ PBT test failed: {e}")
    
    # Test 3: Incremental Learner
    print("\n3. Testing Incremental Learner...")
    try:
        from unity_wheel.orchestrator.incremental_learner import IncrementalLearner
        
        learner = IncrementalLearner(str(Path.cwd()))
        
        # Simulate learning
        test_context = {"task_type": "optimization", "file_count": 5}
        suggestions = await learner.observe_phase_start("assess", test_context)
        
        # Record result
        await learner.observe_phase_result(
            "assess", 
            "gpu_vectorized", 
            {"files_found": 10, "search_depth": 3},
            success=True,
            duration_ms=150
        )
        
        print(f"  ✅ Incremental learner active")
        print(f"  ✅ Patterns tracked: {len(learner.active_patterns)}")
    except Exception as e:
        print(f"  ❌ Incremental learner test failed: {e}")
    
    # Test 4: GPU/MLX availability
    print("\n4. Testing GPU/MLX Availability...")
    try:
        import mlx.core as mx
        import mlx.nn as nn
        
        # Test computation
        dummy = mx.random.normal((128, 384))
        result = mx.matmul(dummy, dummy.T)
        mx.eval(result)
        
        print(f"  ✅ MLX available and working")
        print(f"  ✅ GPU device: {mx.default_device()}")
    except ImportError:
        print(f"  ⚠️  MLX not available - will use CPU fallback")
    except Exception as e:
        print(f"  ❌ MLX test failed: {e}")
    
    # Test 5: Mac hardware detection
    print("\n5. Testing Mac Hardware Detection...")
    try:
        from unity_wheel.orchestrator.unified_mac_optimized_config import MAC_OPTIMIZED_CONFIG
        
        print(f"  ✅ Hardware detected:")
        print(f"     - CPU cores: {MAC_OPTIMIZED_CONFIG.hardware.total_cores}")
        print(f"     - GPU cores: {MAC_OPTIMIZED_CONFIG.hardware.gpu_cores}")
        print(f"     - Memory: {MAC_OPTIMIZED_CONFIG.hardware.total_memory_gb}GB")
    except Exception as e:
        print(f"  ❌ Hardware detection failed: {e}")
    
    print("\n✅ Component tests complete!")
    print("\n💡 To run the full orchestrator:")
    print("   python orchestrate_v3_gpu.py 'optimize trading calculations'")
    print("\n💡 For interactive mode:")
    print("   python orchestrate_v3_gpu.py")

if __name__ == "__main__":
    asyncio.run(test_orchestrator())