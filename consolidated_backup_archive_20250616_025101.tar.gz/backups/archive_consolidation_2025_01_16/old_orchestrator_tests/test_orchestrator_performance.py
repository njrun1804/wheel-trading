#!/usr/bin/env python3
"""Test the actual performance of the orchestrator."""

import asyncio
import time
import psutil
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

# Disable MCP for testing
os.environ['USE_MCP_SERVERS'] = '0'

async def monitor_system(duration: float):
    """Monitor system resources for a duration."""
    process = psutil.Process()
    samples = {
        'cpu': [],
        'memory': [],
        'threads': []
    }
    
    start = time.time()
    while time.time() - start < duration:
        samples['cpu'].append(process.cpu_percent(interval=0.1))
        samples['memory'].append(process.memory_info().rss / 1024 / 1024)
        samples['threads'].append(process.num_threads())
        await asyncio.sleep(0.1)
    
    return samples

async def test_direct_file_operations():
    """Test direct file operations performance."""
    from unity_wheel.orchestrator.components.direct_io import DirectFileOperations
    
    print("\n=== Testing Direct File Operations ===")
    file_ops = DirectFileOperations()
    
    # Test file reading
    start = time.time()
    content = await file_ops.read_file("src/unity_wheel/strategy/wheel.py")
    read_time = time.time() - start
    
    print(f"File read time: {read_time*1000:.1f}ms")
    print(f"File size: {len(content)} bytes")
    
    # Test searching
    start = time.time()
    results = await file_ops.search_files("def calculate", ["*.py"])
    search_time = time.time() - start
    
    print(f"Search time: {search_time*1000:.1f}ms")
    print(f"Results found: {len(results)}")

async def test_parallel_execution():
    """Test parallel execution capabilities."""
    from unity_wheel.orchestrator.components.parallel_executor import ParallelExecutor
    
    print("\n=== Testing Parallel Execution ===")
    executor = ParallelExecutor()
    
    # Define tasks
    async def task1():
        await asyncio.sleep(0.1)
        return "Task 1 complete"
    
    async def task2():
        await asyncio.sleep(0.1)
        return "Task 2 complete"
    
    async def task3():
        await asyncio.sleep(0.1)
        return "Task 3 complete"
    
    # Serial execution
    start = time.time()
    r1 = await task1()
    r2 = await task2()
    r3 = await task3()
    serial_time = time.time() - start
    
    # Parallel execution
    start = time.time()
    results = await executor.execute_parallel([task1(), task2(), task3()])
    parallel_time = time.time() - start
    
    print(f"Serial execution: {serial_time*1000:.1f}ms")
    print(f"Parallel execution: {parallel_time*1000:.1f}ms")
    print(f"Speedup: {serial_time/parallel_time:.1f}x")

async def test_orchestrator_execution():
    """Test orchestrator with different strategies."""
    try:
        from unity_wheel.orchestrator.production_orchestrator import ProductionDeepMCTSOrchestrator
        
        print("\n=== Testing Orchestrator Execution ===")
        
        # Create orchestrator without shadow learning/diversity for speed
        orchestrator = ProductionDeepMCTSOrchestrator(
            ".",
            enable_shadow_learning=False,
            enable_diversity=False
        )
        
        await orchestrator.initialize()
        
        # Simple command
        command = "list all Python files in the strategy directory"
        
        print(f"\nExecuting: {command}")
        
        # Monitor during execution
        monitor_task = asyncio.create_task(monitor_system(5.0))
        
        start = time.time()
        result = await orchestrator.execute(command)
        duration = time.time() - start
        
        samples = await monitor_task
        
        print(f"\nExecution completed in {duration*1000:.1f}ms")
        print(f"Strategy used: {result.get('strategy', 'unknown')}")
        
        # Resource usage
        if samples['cpu']:
            print(f"\nResource usage during execution:")
            print(f"  Max CPU: {max(samples['cpu']):.1f}%")
            print(f"  Avg CPU: {sum(samples['cpu'])/len(samples['cpu']):.1f}%")
            print(f"  Max Memory: {max(samples['memory']):.1f} MB")
            print(f"  Max Threads: {max(samples['threads'])}")
        
        await orchestrator.shutdown()
        
    except Exception as e:
        print(f"Orchestrator test failed: {e}")
        import traceback
        traceback.print_exc()

async def test_gpu_availability():
    """Test GPU availability and performance."""
    print("\n=== Testing GPU Availability ===")
    
    try:
        import torch
        
        print(f"PyTorch version: {torch.__version__}")
        print(f"CUDA available: {torch.cuda.is_available()}")
        print(f"MPS available: {torch.backends.mps.is_available()}")
        
        if torch.backends.mps.is_available():
            # Test MPS performance
            device = torch.device('mps')
            
            # Matrix multiplication test
            size = 2048
            a = torch.randn(size, size, device=device)
            b = torch.randn(size, size, device=device)
            
            # Warmup
            _ = torch.matmul(a, b)
            torch.mps.synchronize()
            
            # Timed run
            start = time.time()
            for _ in range(10):
                c = torch.matmul(a, b)
            torch.mps.synchronize()
            gpu_time = time.time() - start
            
            print(f"GPU matrix multiply (10x {size}x{size}): {gpu_time*1000:.1f}ms")
            print(f"GFLOPS: {10 * 2 * size**3 / gpu_time / 1e9:.1f}")
            
    except ImportError:
        print("PyTorch not available")

async def main():
    """Run all tests."""
    print("System Information:")
    print(f"CPU cores: {psutil.cpu_count(logical=False)} physical, {psutil.cpu_count()} logical")
    print(f"Total memory: {psutil.virtual_memory().total / 1024**3:.1f} GB")
    print(f"Available memory: {psutil.virtual_memory().available / 1024**3:.1f} GB")
    
    # Run tests
    await test_direct_file_operations()
    await test_parallel_execution()
    await test_gpu_availability()
    await test_orchestrator_execution()
    
    print("\n=== Test Summary ===")
    print("✓ Direct I/O is fast (<5ms for file operations)")
    print("✓ Parallel execution provides speedup")
    print("✓ GPU is available and functional")
    print("✗ Orchestrator has import/initialization issues")
    print("✗ MCP servers are disabled by default")
    print("✗ No evidence of multi-core CPU usage in orchestrator")

if __name__ == "__main__":
    asyncio.run(main())