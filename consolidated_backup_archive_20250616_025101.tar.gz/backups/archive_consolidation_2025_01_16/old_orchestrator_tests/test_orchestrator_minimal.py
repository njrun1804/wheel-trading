#!/usr/bin/env python3
"""Minimal test of orchestrator functionality."""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from unity_wheel.orchestrator.simple_orchestrator import SimpleOrchestrator


async def main():
    """Test simple orchestrator."""
    print("Creating simple orchestrator...")
    orchestrator = SimpleOrchestrator(".")
    
    print("Initializing...")
    await orchestrator.initialize()
    
    print("\nExecuting command: 'list Python files'")
    result = await orchestrator.execute("list Python files")
    
    print("\nResult:")
    print(f"Success: {result.get('success', False)}")
    print(f"Files found: {len(result.get('files', []))}")
    
    await orchestrator.shutdown()
    print("\nShutdown complete!")


if __name__ == "__main__":
    asyncio.run(main())