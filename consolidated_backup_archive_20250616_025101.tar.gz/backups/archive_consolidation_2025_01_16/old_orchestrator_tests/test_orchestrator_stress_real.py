#!/usr/bin/env python3
"""Real stress test that actually uses the orchestrator and verifies hardware usage."""

import asyncio
import time
import psutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from unity_wheel.orchestrator.production_orchestrator import ProductionDeepMCTSOrchestrator
from unity_wheel.orchestrator.orchestrator_consolidated import StrategyType
from unity_wheel.orchestrator.strategies.parallel_strategy import ParallelStrategy


class SystemMonitor:
    """Monitor system resource usage."""
    
    def __init__(self):
        self.process = psutil.Process()
        self.start_time = time.time()
        self.samples = []
        self.monitoring = True
        
    async def monitor_loop(self):
        """Continuously monitor resources."""
        while self.monitoring:
            cpu_percent = self.process.cpu_percent(interval=0.1)
            memory_mb = self.process.memory_info().rss / (1024 * 1024)
            threads = self.process.num_threads()
            
            # System-wide CPU
            system_cpu = psutil.cpu_percent(interval=0.1, percpu=True)
            
            self.samples.append({
                "time": time.time() - self.start_time,
                "process_cpu": cpu_percent,
                "system_cpu": system_cpu,
                "memory_mb": memory_mb,
                "threads": threads
            })
            
            # Display real-time
            avg_system_cpu = sum(system_cpu) / len(system_cpu)
            print(f"\rCPU: {cpu_percent:5.1f}% (System: {avg_system_cpu:5.1f}%) | "
                  f"Memory: {memory_mb:6.1f} MB | Threads: {threads:3d}", end='', flush=True)
            
            await asyncio.sleep(0.5)
    
    def stop(self):
        """Stop monitoring."""
        self.monitoring = False
    
    def get_report(self):
        """Generate usage report."""
        if not self.samples:
            return "No samples collected"
        
        # Process CPU
        process_cpu_values = [s["process_cpu"] for s in self.samples]
        peak_process_cpu = max(process_cpu_values)
        avg_process_cpu = sum(process_cpu_values) / len(process_cpu_values)
        
        # System CPU
        system_cpu_samples = [s["system_cpu"] for s in self.samples]
        peak_system_cpu = max(max(sample) for sample in system_cpu_samples)
        avg_system_cpu = sum(sum(sample)/len(sample) for sample in system_cpu_samples) / len(system_cpu_samples)
        
        # Memory
        memory_values = [s["memory_mb"] for s in self.samples]
        peak_memory = max(memory_values)
        avg_memory = sum(memory_values) / len(memory_values)
        
        # Threads
        thread_values = [s["threads"] for s in self.samples]
        peak_threads = max(thread_values)
        
        # Check which CPU cores were used
        core_usage = {}
        for sample in system_cpu_samples:
            for i, usage in enumerate(sample):
                if usage > 10:  # Consider core "used" if >10%
                    core_usage[i] = core_usage.get(i, 0) + 1
        
        cores_used = len([c for c, count in core_usage.items() if count > 5])
        
        return f"""
System Resource Usage Report:
============================
Process CPU:
  Peak: {peak_process_cpu:.1f}%
  Average: {avg_process_cpu:.1f}%

System CPU:
  Peak (any core): {peak_system_cpu:.1f}%
  Average (all cores): {avg_system_cpu:.1f}%
  Cores utilized: {cores_used} / {len(system_cpu_samples[0])}

Memory:
  Peak: {peak_memory:.1f} MB
  Average: {avg_memory:.1f} MB

Threads:
  Peak: {peak_threads}

Duration: {self.samples[-1]['time']:.1f} seconds
Samples: {len(self.samples)}
"""


async def test_basic_orchestrator():
    """Test basic orchestrator functionality."""
    print("\n\n1. Testing Basic Orchestrator")
    print("-" * 60)
    
    monitor = SystemMonitor()
    monitor_task = asyncio.create_task(monitor.monitor_loop())
    
    try:
        # Create orchestrator
        orchestrator = ProductionDeepMCTSOrchestrator(
            workspace_root=".",
            enable_shadow_learning=False,
            enable_diversity=False
        )
        
        # Register parallel strategy as ENHANCED
        orchestrator._strategies[StrategyType.ENHANCED] = ParallelStrategy()
        
        await orchestrator.initialize()
        print("\nOrchestrator initialized")
        
        # Test command
        command = "analyze all Python files in the codebase for optimization opportunities"
        
        print(f"\nExecuting: {command}")
        result = await orchestrator.execute(command, strategy=StrategyType.ENHANCED)
        
        print(f"\n\nResults:")
        print(f"Strategy: {result.get('strategy')}")
        
        if "phases" in result:
            for phase, data in result["phases"].items():
                if isinstance(data, dict):
                    print(f"\n{phase.upper()}:")
                    for key, value in list(data.items())[:5]:
                        if isinstance(value, list):
                            print(f"  {key}: {len(value)} items")
                        else:
                            print(f"  {key}: {value}")
        
        await orchestrator.shutdown()
        
    finally:
        monitor.stop()
        await monitor_task
    
    print(monitor.get_report())


async def test_parallel_workload():
    """Test with multiple parallel commands."""
    print("\n\n2. Testing Parallel Workload")
    print("-" * 60)
    
    monitor = SystemMonitor()
    monitor_task = asyncio.create_task(monitor.monitor_loop())
    
    try:
        # Create orchestrator
        orchestrator = ProductionDeepMCTSOrchestrator(
            workspace_root=".",
            enable_shadow_learning=True,
            enable_diversity=True
        )
        
        # Register parallel strategy as ENHANCED
        orchestrator._strategies[StrategyType.ENHANCED] = ParallelStrategy()
        
        await orchestrator.initialize()
        
        # Multiple commands to run in parallel
        commands = [
            "optimize the math module for GPU acceleration",
            "find all TODO comments and create implementation plan",
            "analyze memory usage patterns in the data structures",
            "refactor the risk analytics engine for better performance"
        ]
        
        print(f"\nExecuting {len(commands)} commands in parallel...")
        
        # Execute all commands in parallel
        tasks = []
        for cmd in commands:
            task = orchestrator.execute(cmd, strategy=StrategyType.ENHANCED)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        print(f"\n\nCompleted {len(results)} tasks")
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                print(f"Task {i+1}: ERROR - {result}")
            else:
                print(f"Task {i+1}: SUCCESS - {result.get('strategy', 'unknown')} strategy")
        
        await orchestrator.shutdown()
        
    finally:
        monitor.stop()
        await monitor_task
    
    print(monitor.get_report())


async def test_gpu_acceleration():
    """Test GPU acceleration if available."""
    print("\n\n3. Testing GPU Acceleration")
    print("-" * 60)
    
    import torch
    
    if torch.cuda.is_available():
        device = "cuda"
        print(f"CUDA available: {torch.cuda.get_device_name(0)}")
    elif torch.backends.mps.is_available():
        device = "mps"
        print("Metal Performance Shaders available")
    else:
        device = "cpu"
        print("No GPU acceleration available")
    
    if device == "cpu":
        print("Skipping GPU test")
        return
    
    monitor = SystemMonitor()
    monitor_task = asyncio.create_task(monitor.monitor_loop())
    
    try:
        # Create some GPU workload
        print("\nRunning GPU workload...")
        
        # Create large tensors
        size = 4096
        a = torch.randn(size, size, device=device)
        b = torch.randn(size, size, device=device)
        
        # Perform operations
        for i in range(10):
            c = torch.matmul(a, b)
            d = torch.nn.functional.softmax(c, dim=1)
            e = d.sum(dim=0)
            
            if device == "cuda":
                torch.cuda.synchronize()
            
            print(f"\rGPU iteration {i+1}/10", end='', flush=True)
        
        print("\n\nGPU test completed")
        
    finally:
        monitor.stop()
        await monitor_task
    
    print(monitor.get_report())


async def main():
    """Run all tests."""
    print("Orchestrator Hardware Usage Test")
    print("=" * 60)
    print("This test will verify that the orchestrator actually uses your hardware.")
    print(f"System: {psutil.cpu_count()} CPU cores, {psutil.virtual_memory().total / (1024**3):.1f} GB RAM")
    
    # Test without MCP servers first
    print("\n\nTesting without MCP servers (direct file operations)...")
    import os
    os.environ["ORCHESTRATOR_MCP_DISABLED"] = "1"
    
    await test_basic_orchestrator()
    
    # Now test with MCP servers
    del os.environ["ORCHESTRATOR_MCP_DISABLED"]
    print("\n\nTesting with MCP servers enabled...")
    
    await test_parallel_workload()
    await test_gpu_acceleration()
    
    print("\n\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    print("Check the resource usage reports above.")
    print("If CPU usage was low, the orchestrator isn't parallelizing properly.")
    print("If only 1-2 cores were used, parallel execution isn't working.")
    print("If thread count stayed low, MCP servers aren't running.")


if __name__ == "__main__":
    asyncio.run(main())