#!/usr/bin/env python3
"""Comprehensive test of orchestrator with hardware acceleration."""

import os
import sys
import asyncio
import time
import psutil
from pathlib import Path
from typing import List, Dict, Any

# Configure environment
os.environ["USE_MCP_SERVERS"] = "0"  # Direct I/O only for testing
os.environ["USE_GPU_ACCELERATION"] = "true"
os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"
os.environ["PYTHONPATH"] = str(Path(__file__).parent)

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))


# Define CPU task at module level for pickling
def cpu_intensive_task(n: int) -> float:
    """CPU-intensive task for testing parallel execution."""
    import math
    total = 0.0
    for i in range(n * 100000):
        total += math.sqrt(i) if i > 0 else 0
    return total


class OrchestratorTester:
    """Comprehensive orchestrator testing suite."""
    
    def __init__(self):
        self.results = {}
        self.start_time = time.time()
        
    async def run_all_tests(self):
        """Run all orchestrator tests."""
        print("🚀 Comprehensive Orchestrator Testing")
        print("=" * 70)
        
        # Test 1: Direct I/O Performance
        await self.test_direct_io()
        
        # Test 2: CPU Parallelization
        await self.test_cpu_parallelization()
        
        # Test 3: GPU Acceleration
        await self.test_gpu_acceleration()
        
        # Test 4: Orchestrator Integration
        await self.test_orchestrator_integration()
        
        # Test 5: Performance Monitoring
        await self.test_performance_monitoring()
        
        # Summary
        self.print_summary()
    
    async def test_direct_io(self):
        """Test direct I/O operations."""
        print("\n📁 Test 1: Direct I/O Performance")
        print("-" * 50)
        
        from unity_wheel.orchestrator.components.direct_io import DirectFileOperations
        file_ops = DirectFileOperations()
        
        start = time.time()
        
        # Test file search
        py_files = await file_ops.glob_files("*.py", "src")
        print(f"Found {len(py_files)} Python files")
        
        # Test parallel read
        if py_files[:5]:  # Read first 5 files
            contents = await file_ops.parallel_read(py_files[:5])
            total_size = sum(len(content) for content in contents.values())
            print(f"Read {len(contents)} files ({total_size:,} bytes) in parallel")
        
        # Test code search
        results = await file_ops.search_code("async def", "src", "*.py")
        print(f"Found 'async def' in {len(results)} files")
        
        elapsed = time.time() - start
        self.results['direct_io'] = {
            'duration': elapsed,
            'files_found': len(py_files),
            'status': 'passed'
        }
        print(f"✅ Direct I/O completed in {elapsed:.3f}s")
    
    async def test_cpu_parallelization(self):
        """Test CPU parallel execution."""
        print("\n🔧 Test 2: CPU Parallelization")
        print("-" * 50)
        
        from unity_wheel.orchestrator.components.parallel_executor import ParallelExecutor
        
        # Monitor CPU before
        cpu_before = psutil.cpu_percent(interval=0.1)
        
        parallel_exec = ParallelExecutor()
        parallel_exec.start()
        
        try:
            # Test with varying workloads
            workloads = [10, 20, 30, 40] * 3  # 12 tasks for 12 cores
            
            start = time.time()
            results = await parallel_exec.map_cpu_bound(cpu_intensive_task, workloads)
            elapsed = time.time() - start
            
            # Monitor CPU during
            cpu_during = psutil.cpu_percent(interval=0.1)
            
            print(f"Executed {len(workloads)} CPU tasks across {parallel_exec.cpu_count} cores")
            print(f"Time: {elapsed:.2f}s")
            print(f"CPU usage: {cpu_before:.1f}% → {cpu_during:.1f}%")
            print(f"Results sum: {sum(results):.0f}")
            
            self.results['cpu_parallel'] = {
                'duration': elapsed,
                'tasks': len(workloads),
                'cpu_peak': cpu_during,
                'status': 'passed' if cpu_during > 50 else 'low_usage'
            }
            
        finally:
            parallel_exec.shutdown()
    
    async def test_gpu_acceleration(self):
        """Test GPU availability and performance."""
        print("\n🎮 Test 3: GPU Acceleration")
        print("-" * 50)
        
        try:
            import torch
            
            if torch.backends.mps.is_available():
                print("✅ Metal Performance Shaders available")
                device = torch.device("mps")
                
                # Warmup
                _ = torch.zeros(1, device=device)
                
                # Performance test
                sizes = [1000, 2000, 4000]
                for size in sizes:
                    start = time.time()
                    
                    # Matrix multiplication on GPU
                    x = torch.randn(size, size, device=device)
                    y = torch.randn(size, size, device=device)
                    z = torch.matmul(x, y)
                    torch.mps.synchronize()
                    
                    elapsed = time.time() - start
                    gflops = (2 * size**3) / (elapsed * 1e9)
                    
                    print(f"  {size}x{size} matmul: {elapsed:.3f}s ({gflops:.1f} GFLOPS)")
                
                self.results['gpu'] = {
                    'available': True,
                    'backend': 'mps',
                    'status': 'passed'
                }
            else:
                print("❌ MPS not available")
                self.results['gpu'] = {'available': False, 'status': 'skipped'}
                
        except ImportError:
            print("❌ PyTorch not installed")
            self.results['gpu'] = {'available': False, 'status': 'missing_pytorch'}
    
    async def test_orchestrator_integration(self):
        """Test the full orchestrator."""
        print("\n🎯 Test 4: Orchestrator Integration")
        print("-" * 50)
        
        try:
            from unity_wheel.orchestrator.simple_orchestrator import SimpleOrchestrator
            
            orchestrator = SimpleOrchestrator(".")
            await orchestrator.initialize()
            
            # Test 1: Simple command
            print("Testing simple command...")
            result = await orchestrator.execute("list Python files in src/unity_wheel/strategy")
            
            if result.get('success'):
                print(f"✅ Simple command successful")
                if 'files' in result:
                    print(f"   Found {len(result.get('files', []))} files")
            
            # Test 2: Complex command
            print("\nTesting complex command...")
            start = time.time()
            result = await orchestrator.execute("analyze all trading strategy code for optimization opportunities")
            elapsed = time.time() - start
            
            print(f"✅ Complex command completed in {elapsed:.2f}s")
            
            await orchestrator.shutdown()
            
            self.results['orchestrator'] = {
                'status': 'passed',
                'complex_duration': elapsed
            }
            
        except Exception as e:
            print(f"❌ Orchestrator error: {e}")
            self.results['orchestrator'] = {'status': 'failed', 'error': str(e)}
    
    async def test_performance_monitoring(self):
        """Test system performance monitoring."""
        print("\n📊 Test 5: Performance Monitoring")
        print("-" * 50)
        
        # System info
        cpu_count = psutil.cpu_count()
        cpu_freq = psutil.cpu_freq()
        memory = psutil.virtual_memory()
        
        print(f"CPU: {cpu_count} cores @ {cpu_freq.current:.0f} MHz")
        print(f"Memory: {memory.used/1024**3:.1f}GB / {memory.total/1024**3:.1f}GB ({memory.percent:.1f}%)")
        
        # Process info
        process = psutil.Process()
        print(f"Process CPU: {process.cpu_percent():.1f}%")
        print(f"Process Memory: {process.memory_info().rss/1024**2:.1f}MB")
        
        self.results['monitoring'] = {
            'cpu_count': cpu_count,
            'memory_percent': memory.percent,
            'status': 'passed'
        }
    
    def print_summary(self):
        """Print test summary."""
        print("\n" + "=" * 70)
        print("📋 TEST SUMMARY")
        print("=" * 70)
        
        total_duration = time.time() - self.start_time
        
        for test_name, result in self.results.items():
            status = result.get('status', 'unknown')
            symbol = "✅" if status == 'passed' else "⚠️" if status in ['skipped', 'low_usage'] else "❌"
            print(f"{symbol} {test_name}: {status}")
            
            if 'duration' in result:
                print(f"   Duration: {result['duration']:.3f}s")
            if 'cpu_peak' in result:
                print(f"   CPU Peak: {result['cpu_peak']:.1f}%")
        
        print(f"\nTotal test duration: {total_duration:.2f}s")
        
        # Final verdict
        passed = sum(1 for r in self.results.values() if r.get('status') == 'passed')
        total = len(self.results)
        
        print(f"\n{'🎉' if passed == total else '⚠️'} {passed}/{total} tests passed")


async def main():
    """Run comprehensive orchestrator tests."""
    tester = OrchestratorTester()
    await tester.run_all_tests()


if __name__ == "__main__":
    asyncio.run(main())