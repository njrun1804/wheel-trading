#!/usr/bin/env python3
"""Test orchestrator hardware utilization - GPU, CPU, and memory stress test."""

import asyncio
import time
import torch
import numpy as np
import psutil
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent))

from src.unity_wheel.orchestrator.strategies.deep_mcts_strategy import (
    DeepMCTS, CodeValueNet, AdaptiveComplexityEstimator
)

print("Deep MCTS Orchestrator Hardware Stress Test")
print("=" * 60)

# Check available hardware
print("\nHardware Detection:")
print(f"CPU cores: {psutil.cpu_count(logical=True)}")
print(f"Memory: {psutil.virtual_memory().total / (1024**3):.1f} GB")

if torch.cuda.is_available():
    print(f"CUDA available: {torch.cuda.device_count()} devices")
    print(f"GPU: {torch.cuda.get_device_name(0)}")
elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
    print("Metal Performance Shaders (MPS) available")
else:
    print("No GPU acceleration available")

# Try to import MLX for M4 Pro
try:
    import mlx.core as mx
    MLX_AVAILABLE = True
    print("MLX available for Apple Silicon")
except ImportError:
    MLX_AVAILABLE = False
    print("MLX not available")


class HardwareMonitor:
    """Monitor CPU, GPU, and memory usage."""
    
    def __init__(self):
        self.process = psutil.Process()
        self.start_time = time.time()
        self.peak_cpu = 0
        self.peak_memory = 0
        self.samples = []
    
    def sample(self):
        """Take a usage sample."""
        cpu_percent = self.process.cpu_percent(interval=0.1)
        memory_mb = self.process.memory_info().rss / (1024 * 1024)
        
        self.peak_cpu = max(self.peak_cpu, cpu_percent)
        self.peak_memory = max(self.peak_memory, memory_mb)
        
        self.samples.append({
            'time': time.time() - self.start_time,
            'cpu': cpu_percent,
            'memory': memory_mb
        })
        
        return cpu_percent, memory_mb
    
    def report(self):
        """Generate usage report."""
        if not self.samples:
            return "No samples collected"
        
        avg_cpu = np.mean([s['cpu'] for s in self.samples])
        avg_memory = np.mean([s['memory'] for s in self.samples])
        
        return f"""
Hardware Usage Report:
  Peak CPU: {self.peak_cpu:.1f}%
  Average CPU: {avg_cpu:.1f}%
  Peak Memory: {self.peak_memory:.1f} MB
  Average Memory: {avg_memory:.1f} MB
  Duration: {time.time() - self.start_time:.1f}s
"""


async def stress_test_mcts(iterations: int = 100):
    """Stress test the MCTS with heavy computation."""
    print("\n\n1. MCTS Stress Test")
    print("-" * 40)
    
    # Create larger value network
    value_net = CodeValueNet(input_dim=1024, hidden_dim=512)
    
    # Use GPU if available
    device = torch.device("cuda" if torch.cuda.is_available() else 
                         "mps" if torch.backends.mps.is_available() else "cpu")
    value_net = value_net.to(device)
    print(f"Using device: {device}")
    
    # Create MCTS with aggressive parameters
    mcts = DeepMCTS(
        value_net=value_net,
        c=3.0,  # Higher exploration
        gpu_batch_size=512  # Large batch size
    )
    
    monitor = HardwareMonitor()
    
    # Background monitoring task
    async def monitor_usage():
        while True:
            cpu, mem = monitor.sample()
            print(f"\rCPU: {cpu:5.1f}% | Memory: {mem:6.1f} MB", end='', flush=True)
            await asyncio.sleep(0.5)
    
    monitor_task = asyncio.create_task(monitor_usage())
    
    try:
        # Run multiple MCTS searches in parallel
        print("\nRunning parallel MCTS searches...")
        
        tasks = []
        for i in range(4):  # 4 parallel searches
            task = mcts.search(
                f"Complex optimization task {i}: Refactor entire codebase for performance",
                {"complexity": 0.9, "parallel_id": i},
                simulations=iterations,
                time_budget_ms=30000
            )
            tasks.append(task)
        
        results = await asyncio.gather(*tasks)
        
        print("\n\nResults:")
        for i, result in enumerate(results):
            print(f"  Search {i}: {result['simulations']} simulations, "
                  f"confidence: {result['confidence']:.3f}")
        
    finally:
        monitor_task.cancel()
        
    print(monitor.report())


async def stress_test_neural_networks():
    """Stress test neural network operations."""
    print("\n\n2. Neural Network Stress Test")
    print("-" * 40)
    
    monitor = HardwareMonitor()
    
    # Create multiple networks
    networks = []
    for i in range(3):
        net = CodeValueNet(input_dim=2048, hidden_dim=1024)
        if torch.cuda.is_available():
            net = net.cuda()
        elif torch.backends.mps.is_available():
            net = net.to('mps')
        networks.append(net)
    
    print(f"Created {len(networks)} large neural networks")
    
    # Generate large batches
    batch_size = 256
    input_dim = 2048
    
    print(f"Processing batches of size {batch_size}...")
    
    for epoch in range(5):
        print(f"\nEpoch {epoch + 1}/5:")
        
        for i in range(10):  # 10 batches per epoch
            # Generate random input
            if torch.cuda.is_available():
                x = torch.randn(batch_size, input_dim).cuda()
            elif torch.backends.mps.is_available():
                x = torch.randn(batch_size, input_dim).to('mps')
            else:
                x = torch.randn(batch_size, input_dim)
            
            # Forward pass through all networks
            outputs = []
            for net in networks:
                with torch.no_grad():
                    out = net(x)
                    outputs.append(out)
            
            # Simulate some computation
            combined = torch.cat(outputs, dim=1)
            result = torch.mean(combined)
            
            cpu, mem = monitor.sample()
            print(f"\r  Batch {i+1}/10 | CPU: {cpu:5.1f}% | Memory: {mem:6.1f} MB", 
                  end='', flush=True)
        
        # Force GPU sync if using CUDA
        if torch.cuda.is_available():
            torch.cuda.synchronize()
    
    print("\n" + monitor.report())


async def stress_test_memory_intensive():
    """Stress test with memory-intensive operations."""
    print("\n\n3. Memory-Intensive Operations Test")
    print("-" * 40)
    
    monitor = HardwareMonitor()
    
    # Large experience buffer simulation
    print("Creating large experience buffers...")
    
    buffers = []
    for i in range(5):
        # Each buffer holds ~100MB of data
        buffer = {
            'features': np.random.randn(10000, 1024).astype(np.float32),
            'values': np.random.randn(10000).astype(np.float32),
            'metadata': [{'id': j, 'data': 'x' * 100} for j in range(10000)]
        }
        buffers.append(buffer)
        
        cpu, mem = monitor.sample()
        print(f"Buffer {i+1}: Memory: {mem:.1f} MB")
    
    # Simulate processing
    print("\nProcessing buffers...")
    for i, buffer in enumerate(buffers):
        # Matrix operations
        result = np.dot(buffer['features'], buffer['features'].T)
        eigenvalues = np.linalg.eigvals(result[:100, :100])  # Subset for speed
        
        cpu, mem = monitor.sample()
        print(f"Processed buffer {i+1}: CPU: {cpu:.1f}%, Memory: {mem:.1f} MB")
    
    print(monitor.report())


async def stress_test_mlx_operations():
    """Test MLX operations if available."""
    if not MLX_AVAILABLE:
        print("\n\n4. MLX Operations Test - SKIPPED (MLX not available)")
        return
    
    print("\n\n4. MLX Operations Test (Apple Silicon)")
    print("-" * 40)
    
    monitor = HardwareMonitor()
    
    # Create large arrays
    print("Creating MLX arrays...")
    size = 4096
    
    # Matrix multiplication stress test
    for i in range(10):
        a = mx.random.normal((size, size))
        b = mx.random.normal((size, size))
        
        # Force computation
        c = mx.matmul(a, b)
        mx.eval(c)
        
        cpu, mem = monitor.sample()
        print(f"Iteration {i+1}: CPU: {cpu:.1f}%, Memory: {mem:.1f} MB")
    
    print(monitor.report())


async def run_production_scenario():
    """Run a realistic production scenario."""
    print("\n\n5. Production Scenario Test")
    print("-" * 40)
    
    from src.unity_wheel.orchestrator.production_orchestrator import ProductionDeepMCTSOrchestrator
    
    monitor = HardwareMonitor()
    
    # Create orchestrator
    orchestrator = ProductionDeepMCTSOrchestrator(
        workspace_root=".",
        enable_shadow_learning=True,
        enable_diversity=True
    )
    
    # Complex commands that should stress the system
    commands = [
        "Refactor the entire options pricing engine to use GPU acceleration with MLX",
        "Optimize the risk analytics system for real-time processing of 10000 contracts",
        "Implement a new MCTS-based portfolio optimization algorithm with deep learning"
    ]
    
    print("Running complex commands...")
    
    for i, command in enumerate(commands):
        print(f"\nCommand {i+1}: {command[:50]}...")
        
        start = time.time()
        
        # This should trigger heavy computation
        try:
            # Skip actual execution since MCP servers aren't configured
            # Just test the strategy components
            strategy = orchestrator._strategies.get(orchestrator._default_strategy)
            if not strategy:
                strategy = orchestrator._strategies[orchestrator._default_strategy] = \
                    await orchestrator._load_strategy(orchestrator._default_strategy)
            
            # Test complexity estimation
            complexity = strategy.complexity_estimator.estimate(command, {})
            print(f"  Complexity: {complexity:.3f}")
            
            # Test MCTS search
            result = await strategy.mcts.search(
                command, 
                {"complexity": complexity},
                simulations=500 if complexity > 0.5 else 200
            )
            
            print(f"  MCTS: {result['simulations']} simulations, "
                  f"confidence: {result['confidence']:.3f}")
            
        except Exception as e:
            print(f"  Error: {e}")
        
        duration = time.time() - start
        cpu, mem = monitor.sample()
        print(f"  Duration: {duration:.1f}s, CPU: {cpu:.1f}%, Memory: {mem:.1f} MB")
    
    print(monitor.report())


async def main():
    """Run all stress tests."""
    print("\nStarting hardware stress tests...")
    print("Monitor your system's activity monitor to verify usage!\n")
    
    tests = [
        ("MCTS Stress Test", stress_test_mcts),
        ("Neural Network Test", stress_test_neural_networks),
        ("Memory Intensive Test", stress_test_memory_intensive),
        ("MLX Operations Test", stress_test_mlx_operations),
        ("Production Scenario", run_production_scenario)
    ]
    
    overall_monitor = HardwareMonitor()
    
    for name, test_func in tests:
        try:
            await test_func()
        except Exception as e:
            print(f"\n{name} failed: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "=" * 60)
    print("Overall Hardware Usage:")
    print("=" * 60)
    print(overall_monitor.report())
    
    # Check if we're actually using the hardware
    if overall_monitor.peak_cpu < 50:
        print("\n⚠️  WARNING: Peak CPU usage was low. The system may not be ")
        print("   properly utilizing multiple cores. Check thread pool settings.")
    
    if overall_monitor.peak_memory < 1000:  # Less than 1GB
        print("\n⚠️  WARNING: Peak memory usage was low. The system may not be")
        print("   properly utilizing available memory for caching/batching.")
    
    print("\nTo properly stress the system, you may need to:")
    print("1. Increase batch sizes in the neural networks")
    print("2. Run more parallel MCTS searches")
    print("3. Use larger models (increase hidden dimensions)")
    print("4. Enable GPU acceleration if available")


if __name__ == "__main__":
    asyncio.run(main())