#!/usr/bin/env python3
"""Final test to verify orchestrator is working and using hardware."""

import asyncio
import time
import psutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))


async def test_orchestrator():
    """Test the orchestrator with hardware monitoring."""
    print("Final Orchestrator Test")
    print("=" * 60)
    
    # Import what we need
    from unity_wheel.orchestrator.production_orchestrator import create_production_orchestrator
    
    # Monitor resources
    process = psutil.Process()
    start_cpu = process.cpu_percent(interval=0.1)
    start_memory = process.memory_info().rss / (1024 * 1024)
    start_threads = process.num_threads()
    
    print(f"Initial state: CPU={start_cpu:.1f}%, Memory={start_memory:.1f}MB, Threads={start_threads}")
    
    try:
        # Create orchestrator
        print("\nCreating orchestrator...")
        orchestrator = await create_production_orchestrator(".")
        
        # Check device
        if hasattr(orchestrator, '_strategies'):
            for name, strategy in orchestrator._strategies.items():
                if hasattr(strategy, 'device'):
                    print(f"Strategy {name} using device: {strategy.device}")
                elif hasattr(strategy, 'mcts') and hasattr(strategy.mcts, 'device'):
                    print(f"Strategy {name} MCTS using device: {strategy.mcts.device}")
        
        # Simple test command
        command = "find all Python files and analyze their structure"
        print(f"\nExecuting: {command}")
        
        # Track CPU during execution
        cpu_samples = []
        
        async def monitor():
            while True:
                cpu = process.cpu_percent(interval=0.1)
                mem = process.memory_info().rss / (1024 * 1024)
                threads = process.num_threads()
                cpu_samples.append(cpu)
                print(f"\rCPU: {cpu:5.1f}% | Memory: {mem:6.1f}MB | Threads: {threads:3d}", 
                      end='', flush=True)
                await asyncio.sleep(0.5)
        
        # Start monitoring
        monitor_task = asyncio.create_task(monitor())
        
        # Execute command
        start_time = time.time()
        result = await orchestrator.execute(command)
        duration = time.time() - start_time
        
        # Stop monitoring
        monitor_task.cancel()
        try:
            await monitor_task
        except asyncio.CancelledError:
            pass
        
        print(f"\n\nExecution completed in {duration:.2f} seconds")
        print(f"Strategy used: {result.get('strategy', 'unknown')}")
        
        # Check results
        if "phases" in result:
            print("\nPhases completed:")
            for phase, data in result["phases"].items():
                if isinstance(data, dict):
                    print(f"  {phase}: {data.get('duration_ms', 'N/A')}ms")
        
        if "execution_metrics" in result:
            metrics = result["execution_metrics"]
            print(f"\nExecution metrics:")
            print(f"  Duration: {metrics.get('duration_ms', 0):.1f}ms")
            print(f"  CPU: {metrics.get('cpu_percent', 0):.1f}%")
            print(f"  Memory: {metrics.get('memory_mb', 0):.1f}MB")
        
        # Resource usage summary
        peak_cpu = max(cpu_samples) if cpu_samples else 0
        avg_cpu = sum(cpu_samples) / len(cpu_samples) if cpu_samples else 0
        
        print(f"\nResource usage:")
        print(f"  Peak CPU: {peak_cpu:.1f}%")
        print(f"  Average CPU: {avg_cpu:.1f}%")
        print(f"  Samples collected: {len(cpu_samples)}")
        
        # Check if we used multiple cores
        system_cpu = psutil.cpu_percent(interval=0.1, percpu=True)
        active_cores = sum(1 for cpu in system_cpu if cpu > 10)
        print(f"  Active CPU cores: {active_cores} / {len(system_cpu)}")
        
        # Verdict
        print("\nVerdict:")
        if avg_cpu < 20:
            print("  ⚠️  Low CPU usage - orchestrator may not be parallelizing")
        else:
            print("  ✓ Good CPU usage")
        
        if active_cores < 2:
            print("  ⚠️  Only using 1 core - parallel execution not working")
        else:
            print(f"  ✓ Using {active_cores} cores")
        
        await orchestrator.shutdown()
        
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()


async def test_mcp_client():
    """Test the fixed MCP client directly."""
    print("\n\nTesting Fixed MCP Client")
    print("-" * 60)
    
    from unity_wheel.orchestrator.components.mcp_client_fixed import MCPClient
    
    client = MCPClient("mcp-servers.json", max_parallel=4)
    
    print("Initializing filesystem server...")
    await client.initialize(["filesystem"])
    
    if "filesystem" in client.connections:
        print("✓ Filesystem server started")
        
        # Test parallel calls
        print("\nTesting parallel file operations...")
        
        calls = [
            ("filesystem", "read_file", {"path": "run.py"}),
            ("filesystem", "read_file", {"path": "setup.py"}),
            ("filesystem", "read_file", {"path": "README.md"}),
        ]
        
        start = time.time()
        results = await client.parallel_call(calls)
        duration = time.time() - start
        
        success_count = sum(1 for r in results if not isinstance(r, Exception))
        print(f"Parallel calls: {success_count}/{len(calls)} successful in {duration:.2f}s")
        
        # Check metrics
        metrics = client.get_metrics()
        for key, stats in metrics.items():
            print(f"  {key}: {stats['calls']} calls, {stats['avg_ms']:.1f}ms avg")
    else:
        print("✗ Failed to start filesystem server")
    
    await client.shutdown()


if __name__ == "__main__":
    print("Testing the orchestrator to verify it's actually using hardware...\n")
    
    asyncio.run(test_orchestrator())
    asyncio.run(test_mcp_client())